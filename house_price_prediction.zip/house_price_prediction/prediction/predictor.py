# prediction/predictor.py
def predict_price(area, bedrooms, bathrooms):
    # Replace this with your machine learning model prediction logic
    # For simplicity, return a random value
    import random
    return random.uniform(10000, 50000)
