# prediction/urls.py
from django.urls import path
from .views import predict, result

urlpatterns = [
    path('predict/', predict, name='predict'),
    path('result/', result, name='result'),
]
